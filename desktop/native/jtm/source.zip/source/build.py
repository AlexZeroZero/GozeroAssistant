"""Build the source-pinned JTM fork using the workspace Rust/MinGW toolchain."""
from pathlib import Path
import os, subprocess, shutil, sys
src=Path(__file__).resolve().parent
root=src.parents[2]
b=Path(os.environ['LOCALAPPDATA'])/'GozeroBuild/blocknet-0.1'
gcc=b.parent/'xmrig-cpu-6.26.0/toolchain/mingw64/bin'
target=b.parent/'jtm/target'
env={**os.environ,'PATH':str(b/'rust/bin')+';'+str(gcc)+';'+os.environ['PATH'],'CARGO_HOME':str(b/'cargo-home'),'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'4'}
out=root/'desktop/artifacts/jtm';out.mkdir(parents=True,exist_ok=True)
cmd='test' if '--test' in sys.argv else 'build'
with (out/(cmd+'.log')).open('w',encoding='utf-8') as log:
 p=subprocess.run([str(b/'rust/bin/cargo.exe'),cmd,'--release','--locked','--manifest-path',str(src/'Cargo.toml')],env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
print((out/(cmd+'.log')).read_text(encoding='utf-8')[-3000:])
if p.returncode==0 and cmd=='build':shutil.copy2(target/'release/towerminer.exe',out/'GozeroJtmCore.exe')
raise SystemExit(p.returncode)
