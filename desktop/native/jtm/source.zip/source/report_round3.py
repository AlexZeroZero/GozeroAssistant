"""Evidence from this round; intentionally distinguish exploratory and full-load results."""
from pathlib import Path
import json, hashlib, difflib

src=Path(__file__).resolve().parent
desktop=src.parents[1]
out=desktop/'artifacts/jtm-round3'
results=[]
for path in sorted(out.glob('*.json')):
    if path.name in ('summary.json','manifest.json'): continue
    rows=json.loads(path.read_text(encoding='utf8'))
    if not isinstance(rows,list) or len(rows) not in (4,6) or not all('label' in r for r in rows): continue
    means={label:sum(r['hps'] for r in rows if r['label']==label)/2 for label in set(r['label'] for r in rows)}
    candidate=next(k for k in means if k not in ('round2','shipped'))
    results.append({'file':path.name,'threads':rows[0]['threads'],'seconds':rows[0]['seconds'],
                    'candidate':candidate,'means':means,'change_vs_round2_percent':100*(means[candidate]/means['round2']-1)})
(out/'summary.json').write_text(json.dumps(results,indent=2),encoding='utf8')
name='asm-bmi2-distributive'
old=(desktop/'artifacts/jtm-round2/recompute.rs').read_text(encoding='utf8')
new=(out/(name+'.rs')).read_text(encoding='utf8')
(out/'candidate-vs-round2.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),
    fromfile='a/towerminer/src/walk.rs',tofile='b/towerminer/src/walk.rs')),encoding='utf8')
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.suffix in ('.exe','.rs','.patch')}
manifest['round2-reference.exe']=hashlib.sha256((desktop/'artifacts/jtm-round2/recompute.exe').read_bytes()).hexdigest()
manifest['shipped-core.exe']=hashlib.sha256((desktop/'native/jtm/GozeroJtmCore.exe').read_bytes()).hexdigest()
(out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
lines=['JTM TowerWalk 第三轮优化验证 / 2026-10-18','',
 '结论：本轮没有证明比上一轮候选稳定、显著更快的整机方案。',
 'BMI2 + 轮次项提前计算在 4 线程下约 +3.38%；24 线程两组分别 -0.13% 和 +2.42%。',
 '因此保留为实验候选，上一轮 recompute 继续作为参考；不替换正式助手。','',
 '设备：Intel Core Ultra 9 275HX，24 核 / 24 线程，Windows x64，普通 4 KiB 页。',
 'host-features.txt 确认本机具有 AVX2、BMI2；实验不适用于推断其他 CPU 的收益。',
 '每组按对称顺序串行测试；无并行编译或其它实验挤占测速。',
 '未锁定频率、功率和温度，也未读取到这些传感数值；小差异不当作确定性提升。',
 '同组线程数、pads=2、预取配置、优先级一致；预取/布局候选的实际行为变化由名称标出。','',
 '六种新实现：',
 '1. asm：8 个累加状态保留于寄存器，每次执行完整 8192 轮。',
 '2. asm-lane：独立内存块之间交错执行，保留每块内部通道顺序。',
 '3. asm-bmi2-distributive：RORX 缩短地址生成；模 2^64 分配律提前计算轮次项。',
 '4. prefetch-l2：改变预取目标缓存层级，实测退步。',
 '5. skew64：各 512 KiB 内存块间增加 64 字节间距，实测没有明确收益。',
 '6. avx2-gather：4 路 gather 与向量乘法；地址冲突时回退顺序步骤，实测退步。','',
 '与上一轮最佳候选直接对照（H/s）：']
for r in results:
    means=r['means']
    lines.append(f"{r['file']}：参考 {means['round2']:.2f}；实验 {means[r['candidate']]:.2f}；{r['change_vs_round2_percent']:+.2f}%")
    if 'shipped' in means:
        lines.append(f"  同组正式 1.0.54 内核 {means['shipped']:.2f}；这里不能把新旧轮次百分比简单累加。")
lines+=['','正确性：',
 '所有六种候选 --gate 均通过：256 golden vectors + 1000 random seeds，链数 1–4、预取开关、槽位轮换。',
 '没有减少内存大小、轮数、折叠次数或最终哈希步骤。',
 'BMI2 快速路径仅在 CPU 支持、两个连续且不重叠内存块、正常通道顺序时使用，否则执行通用路径。',
 '轮次项证明：(x+r)*C = x*C+r*C (mod 2^64)。C 为奇数，r*C 的低 13 位为零当且仅当 r 的低 13 位为零。',
 '向量路径先检查全部六对地址是否相等，发生冲突时保留后续通道读取先前写入的语义。']
for filename,needle in [('identity-test.log','1 passed'),('collision-test.log','1 passed')]:
    p=out/filename
    lines.append(filename+': '+('PASS' if p.exists() and needle in p.read_text(encoding='utf8',errors='replace') else 'NOT VERIFIED'))
p=out/(name+'-nonces.log')
if p.exists(): lines.extend(s for s in p.read_text(encoding='utf8',errors='replace').splitlines() if s.startswith('CHECK-NONCES'))
lines+=['','限制与交付状态：',
 '当前仍无可用 JTM 实池，以上都是离线工作循环与本地正确性结果；没有实池收益结算结论。',
 '未改变大页权限、安全软件或系统电源策略。未改变 MDS，未打包或发布新正式版。',
 '上一轮原生 RPC 单元测试超时问题未在本轮修复；本轮专项测试通过不代表完整原生测试套件全通过。',
 '新旧源码、可执行文件哈希、补丁、原始输出、测量脚本均已保留。']
(out/'ROUND3-VALIDATION.txt').write_text('\n'.join(lines)+'\n',encoding='utf8')
print('\n'.join(lines))
