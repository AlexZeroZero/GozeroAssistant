"""Offline cache-domain measurements on the detected local 275HX topology."""
from pathlib import Path
import subprocess,re,json
desktop=Path(__file__).resolve().parents[2]
out=desktop/'artifacts/jtm-round2';exe=desktop/'native/jtm/GozeroJtmCore.exe'
# Verified GetLogicalProcessorInformationEx mapping, recorded in topology.json.
groups={'P':'0,1,10,11,12,13,22,23','E':'2-9,14-21'}
rows=[]
for group,pads in [('P',2),('P',3),('P',4),('P',1),('E',2),('E',1),('E',3),('E',4)]:
 p=subprocess.run([str(exe),'--cpus',groups[group],'--pads',str(pads),'--prefetch','1','--bench-walk','10','--no-tune-file','--idle-secs','0'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=40,creationflags=subprocess.CREATE_NO_WINDOW)
 (out/f'group-{group}-{pads}.log').write_bytes(p.stdout);m=re.search(rb'\bhps=([\d.]+)',p.stdout)
 if p.returncode or not m:raise RuntimeError(p.stdout.decode('utf8','replace')[-1200:])
 row={'group':group,'cpus':groups[group],'pads':pads,'hps':float(m[1])};rows.append(row);print(row,flush=True)
 (out/'group-comparison.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
