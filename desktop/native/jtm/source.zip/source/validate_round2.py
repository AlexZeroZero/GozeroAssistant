"""Targeted correctness checks, without hiding unrelated upstream test failures."""
from pathlib import Path
import os, subprocess, sys

desktop = Path(__file__).resolve().parents[2]
lab = desktop / 'experiments/jetsam-lab-round2'
out = desktop / 'artifacts/jtm-round2'
build = Path(os.environ['LOCALAPPDATA']) / 'GozeroBuild/blocknet-0.1'
env = dict(os.environ)
env.update(PATH=str(build/'rust/bin')+';'+str(build.parent/'xmrig-cpu-6.26.0/toolchain/mingw64/bin')+';'+env['PATH'],
           CARGO_HOME=str(build/'cargo-home'), CARGO_TARGET_DIR=str(build.parent/'jtm-lab/target'), CARGO_BUILD_JOBS='4')
if sys.argv[1] == 'alias':
    args = [str(build/'rust/bin/cargo.exe'), 'test', '--release', '--locked', '--manifest-path',
            str(lab/'Cargo.toml'), 'group_alias_patterns_match_sequential', '--', '--nocapture']
    log = out / 'alias-test.log'
else:
    name = sys.argv[1]
    args = [str(out/(name+'.exe')), '--check-nonces', '20', '--threads', '4',
            '--pads', '2', '--prefetch', '1', '--no-tune-file', '--idle-secs', '0']
    log = out / (name+'-nonces.log')
with log.open('wb') as f:
    result = subprocess.run(args, env=env, stdout=f, stderr=subprocess.STDOUT,
                            timeout=240, creationflags=subprocess.CREATE_NO_WINDOW)
text = log.read_text(encoding='utf8', errors='replace')
print(text[-3000:])
if sys.argv[1] == 'alias' and '1 passed' not in text:
    raise RuntimeError('Expected alias test did not execute successfully')
raise SystemExit(result.returncode)
