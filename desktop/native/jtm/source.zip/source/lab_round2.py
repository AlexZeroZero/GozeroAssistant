"""Isolated TowerWalk scheduling experiments. Never replaces the shipped core."""
from pathlib import Path
import os,sys,shutil,subprocess,json,re,hashlib
src=Path(__file__).resolve().parent
desktop=src.parents[1]
lab=desktop/'experiments/jetsam-lab-round2'
out=desktop/'artifacts/jtm-round2';out.mkdir(parents=True,exist_ok=True)
if not lab.exists():shutil.copytree(src,lab,ignore=shutil.ignore_patterns('__pycache__','target'))
base=(src/'towerminer/src/walk.rs').read_text(encoding='utf8')
b=Path(os.environ['LOCALAPPDATA'])/'GozeroBuild/blocknet-0.1'
env={**os.environ,'PATH':str(b/'rust/bin')+';'+str(b.parent/'xmrig-cpu-6.26.0/toolchain/mingw64/bin')+';'+os.environ['PATH'],'CARGO_HOME':str(b/'cargo-home'),'CARGO_TARGET_DIR':str(b.parent/'jtm-lab/target'),'CARGO_BUILD_JOBS':'4'}
original='''                for li in 0..4 {
                    let l = LANES[li];
                    if simple(K, P) {
                        step::<true, PF>(v, &mut off[p][l], &mut a[p][l], rr as u64);
                    } else {
                        step::<false, PF>(v, &mut off[p][l], &mut a[p][l], rr as u64);
                    }
                }'''
helper='''
// All reads occur before stores, then each alias observes the most recent
// earlier lane's write. This preserves sequential semantics even if all four
// offsets alias; the consensus gate checks complete hashes against the oracle.
#[inline(always)]
unsafe fn step_forward<const PF: bool>(v: *mut u8, off: &mut [usize;4], a: &mut [u64;4], rr:u64) {
    let old = *off;
    let mut value=[0u64;4];
    for l in 0..4 { value[l]=*(v.add(old[l]) as *const u64); }
    let mut write=[0u64;4];
    for li in 0..4 {
        let l=LANES[li]; let mut val=value[l];
        for ki in 0..li { let k=LANES[ki]; if old[l]==old[k] { val=write[k]; } }
        let y=(a[l]^val).wrapping_add(rr).wrapping_mul(MULT_C);
        let n=y^(y>>XS); a[l]=n; write[l]=n.wrapping_add(val); off[l]=off_of(n);
    }
    for li in 0..4 { let l=LANES[li]; *(v.add(old[l]) as *mut u64)=write[l]; }
    if PF { for l in 0..4 {core::arch::x86_64::_mm_prefetch::<{core::arch::x86_64::_MM_HINT_T0}>(v.add(off[l]) as *const i8);} }
}
#[inline(always)]
unsafe fn step_disjoint<const PF:bool>(v:*mut u8,off:&mut[usize;4],a:&mut[u64;4],rr:u64) {
    let old=*off;
    if old[0]==old[1] || old[0]==old[2] || old[0]==old[3] || old[1]==old[2] || old[1]==old[3] || old[2]==old[3] {
        for li in 0..4 {let l=LANES[li];step::<false,PF>(v,&mut off[l],&mut a[l],rr);}
    } else {
        let mut val=[0u64;4];let mut written=[0u64;4];
        for l in 0..4 { val[l]=*(v.add(old[l]) as *const u64); }
        for l in 0..4 {let y=(a[l]^val[l]).wrapping_add(rr).wrapping_mul(MULT_C);let n=y^(y>>XS);a[l]=n;off[l]=off_of(n);written[l]=n.wrapping_add(val[l]);}
        for l in 0..4 {*(v.add(old[l]) as *mut u64)=written[l];}
        if PF {for l in 0..4 {core::arch::x86_64::_mm_prefetch::<{core::arch::x86_64::_MM_HINT_T0}>(v.add(off[l]) as *const i8);}}
    }
}
#[inline(always)]
unsafe fn step_pairs<const PF:bool>(v:*mut u8,off:&mut[usize;4],a:&mut[u64;4],rr:u64) {
    for pair in 0..2 {
        let l=LANES[pair*2]; let k=LANES[pair*2+1];
        let x=off[l]; let z=off[k];
        let va=*(v.add(x) as *const u64); let mut vb=*(v.add(z) as *const u64);
        let ya=(a[l]^va).wrapping_add(rr).wrapping_mul(MULT_C);let na=ya^(ya>>XS);let wa=na.wrapping_add(va);
        if x==z {vb=wa;}
        let yb=(a[k]^vb).wrapping_add(rr).wrapping_mul(MULT_C);let nb=yb^(yb>>XS);
        *(v.add(x) as *mut u64)=wa;*(v.add(z) as *mut u64)=nb.wrapping_add(vb);
        a[l]=na;a[k]=nb;off[l]=off_of(na);off[k]=off_of(nb);
        if PF {core::arch::x86_64::_mm_prefetch::<{core::arch::x86_64::_MM_HINT_T0}>(v.add(off[l]) as *const i8);core::arch::x86_64::_mm_prefetch::<{core::arch::x86_64::_MM_HINT_T0}>(v.add(off[k]) as *const i8);}
    }
}
#[cfg(test)]
#[test]
fn group_alias_patterns_match_sequential() {
    for pattern in 0..256usize {
        let original_offsets=[(pattern&3)*8,((pattern>>2)&3)*8,((pattern>>4)&3)*8,((pattern>>6)&3)*8];
        for rr in [0u64,8191,u64::MAX] {
            let initial=[u64::MAX,123456789,0,0x8f1d284abcdeffff];
            let mut expected=vec![0u64;CELLS];expected[..4].copy_from_slice(&[23,45,67,u64::MAX]);
            let mut state=initial;let mut offsets=original_offsets;
            unsafe {for li in 0..4 {let l=LANES[li];step::<false,true>(expected.as_mut_ptr() as *mut u8,&mut offsets[l],&mut state[l],rr);} }
            for method in 0..3 {
                let mut actual=vec![0u64;CELLS];actual[..4].copy_from_slice(&[23,45,67,u64::MAX]);let mut a=initial;let mut o=original_offsets;
                unsafe {let p=actual.as_mut_ptr() as *mut u8;match method {0=>step_forward::<true>(p,&mut o,&mut a,rr),1=>step_disjoint::<true>(p,&mut o,&mut a,rr),_=>step_pairs::<true>(p,&mut o,&mut a,rr)}}
                assert_eq!(actual,expected,"memory pattern={pattern} method={method}");assert_eq!(a,state);assert_eq!(o,offsets);
            }
        }
    }
}
'''
probe=base.replace('    let mut a = [[0u64; 4]; P];','    let probe_begin=std::time::Instant::now(); let mut fold_ns=0u64;\n    let mut a = [[0u64; 4]; P];')
probe=probe.replace('fold_all::<P, K>(&mut a, &mut c);','{let ft=std::time::Instant::now();fold_all::<P, K>(&mut a, &mut c);fold_ns+=ft.elapsed().as_nanos() as u64;}')
probe=probe.replace('    // Walk.','    let fill_total=probe_begin.elapsed().as_nanos() as u64;let fill_fold=fold_ns;\n    // Walk.')
needle='    }\n}\n\n/// Runtime dispatch over the compiled'
probe=probe.replace(needle,'    }\n    probe_record(fill_total-fill_fold,fold_ns,(probe_begin.elapsed().as_nanos() as u64).saturating_sub(fill_total+fold_ns-fill_fold));\n}\n\n/// Runtime dispatch over the compiled')
probe+='''
fn probe_record(fill:u64,fold:u64,walk:u64) {
    use std::sync::atomic::{AtomicU64,Ordering};
    static F:AtomicU64=AtomicU64::new(0);static D:AtomicU64=AtomicU64::new(0);static W:AtomicU64=AtomicU64::new(0);static N:AtomicU64=AtomicU64::new(0);
    F.fetch_add(fill,Ordering::Relaxed);D.fetch_add(fold,Ordering::Relaxed);W.fetch_add(walk,Ordering::Relaxed);
    let n=N.fetch_add(1,Ordering::Relaxed)+1;
    if n%512==0 {eprintln!("PHASE calls={} fill_ns={} fold_ns={} walk_ns={}",n,F.load(Ordering::Relaxed),D.load(Ordering::Relaxed),W.load(Ordering::Relaxed));}
}
'''
variants={'probe':probe,'forward':base.replace(original,'                step_forward::<PF>(v,&mut off[p],&mut a[p],rr as u64);')+helper,
 'disjoint':base.replace(original,'                step_disjoint::<PF>(v,&mut off[p],&mut a[p],rr as u64);')+helper,
 'pairs':base.replace(original,'                step_pairs::<PF>(v,&mut off[p],&mut a[p],rr as u64);')+helper,
 'prefetch-l2':base.replace('_MM_HINT_T0','_MM_HINT_T1'),
 'recompute':base.replace('let ptr = v.add(*off) as *mut u64;','let ptr = v.add(off_of(*a)) as *mut u64;').replace('    *off = next;','    let _ = off;'),
 'baseline':base}
variants['recompute-lane'] = variants['recompute'].replace('''            for p in 0..P {
                let v = pads[p] as *mut u8;
                for li in 0..4 {
                    let l = LANES[li];''','''            for li in 0..4 {
                let l = LANES[li];
                for p in 0..P {
                    let v = pads[p] as *mut u8;''')
variants['recompute-byte'] = variants['recompute'].replace('v.add(off_of(*a))', 'v.add(((((*a) << 3) ^ ((*a) >> 29)) & OFF_MASK) as usize)')
loop_begin = '        for rr in r..r + PERM_PERIOD {'
loop_end = '        }\n        r += PERM_PERIOD;'
variants['recompute-unroll2'] = variants['recompute'].replace(loop_begin, '        for chunk in (r..r + PERM_PERIOD).step_by(2) {\n          for unroll in 0..2 {\n            let rr = chunk + unroll;').replace(loop_end, '          }\n'+loop_end)
if original not in base:raise RuntimeError('Hot loop not located')
name=sys.argv[1]
variants['hetero'] = base
variants['hetero-recompute'] = variants['recompute']
variants['native'] = base
variants['recompute-native'] = variants['recompute']
if name.endswith('native'):
    # Local experiment only; never replace the portable binary with this.
    env['RUSTFLAGS'] = '-C target-cpu=native'
    env['CARGO_TARGET_DIR'] = str(b.parent/'jtm-lab-native/target')
main_source = (src/'towerminer/src/main.rs').read_text(encoding='utf8')
if name.startswith('hetero'):
    # LAB ONLY: IDs below were measured with Windows processor/cache topology APIs.
    # Never deploy this machine-specific profile to another computer.
    main_source = main_source.replace('struct Profile {', '#[derive(Clone)]\nstruct Profile {', 1)
    main_source = main_source.replace('        let (prof, sh, tx) = (prof.clone(), sh.clone(), tx.clone());', '''        let mut local = (**prof).clone();
        if [0usize,1,10,11,12,13,22,23].contains(&cpu) { local.pads = 3; }
        else { local.pads = 2; }
        local.pipe = false;
        local.seed_batch = local.pads;
        eprintln!("LAB topology worker={} cpu={} pads={}", id, cpu, local.pads);
        let (prof, sh, tx) = (Arc::new(local), sh.clone(), tx.clone());''')
(lab/'towerminer/src/main.rs').write_text(main_source,encoding='utf8')
(out/(name+'-main.rs')).write_text(main_source,encoding='utf8')
(lab/'towerminer/src/walk.rs').write_text(variants[name],encoding='utf8')
(out/(name+'.rs')).write_text(variants[name],encoding='utf8')
with (out/(name+'-build.log')).open('wb') as f:
 p=subprocess.run([str(b/'rust/bin/cargo.exe'),'build','--release','--locked','--manifest-path',str(lab/'Cargo.toml')],env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
if p.returncode:raise RuntimeError((out/(name+'-build.log')).read_text(encoding='utf8')[-3000:])
exe=out/(name+'.exe');shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'release/towerminer.exe',exe)
with (out/(name+'-gate.log')).open('wb') as f:
 p=subprocess.run([str(exe),'--gate'],stdout=f,stderr=subprocess.STDOUT,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
if p.returncode:raise RuntimeError('Gate failed: '+name)
print(name+' GATE PASS',flush=True)
if name.startswith('hetero'):
 p=subprocess.run([sys.executable,str(src/'compare_round2.py'),name,'25','24','2'])
 raise SystemExit(p.returncode)
if name=='probe':
 p=subprocess.run([str(exe),'--bench-walk','8','--threads','4','--pads','2','--prefetch','1','--no-tune-file','--idle-secs','0'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
 (out/'phase-profile.log').write_bytes(p.stdout);print(p.stdout.decode('utf8','replace')[-2200:]);raise SystemExit(p.returncode)
results=[]
for i,(program,label) in enumerate([(desktop/'native/jtm/GozeroJtmCore.exe','shipped'),(exe,name),(exe,name),(desktop/'native/jtm/GozeroJtmCore.exe','shipped')],1):
 args=[str(program),'--bench-walk','12','--threads','4','--threads-per-core','2','--pads','2','--prefetch','1','--no-tune-file','--idle-secs','0']
 p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
 (out/f'{name}-{i}.log').write_bytes(p.stdout)
 m=re.search(rb'\bhps=([\d.]+)',p.stdout)
 if p.returncode or not m:raise RuntimeError(p.stdout.decode('utf8','replace')[-2000:])
 row={'candidate':name,'label':label,'hps':float(m[1]),'threads':4,'pads':2,'prefetch':1,'sha256':hashlib.sha256(program.read_bytes()).hexdigest()};results.append(row);print(row,flush=True)
 (out/(name+'-comparison.json')).write_text(json.dumps(results,indent=2),encoding='utf8')
