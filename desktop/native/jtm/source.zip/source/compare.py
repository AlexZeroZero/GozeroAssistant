"""Alternate same-compiler upstream vs final fork on this machine, offline only."""
from pathlib import Path
import subprocess,json,re,hashlib
out=Path(__file__).resolve().parents[2]/'artifacts/jtm'
rows=[]
for i,name in enumerate(['towerminer-official-source.exe','GozeroJtmCore.exe','GozeroJtmCore.exe','towerminer-official-source.exe'],1):
 exe=out/name
 args=[str(exe),'--bench-walk','20','--threads','24','--threads-per-core','2','--pads','2','--prefetch','1','--no-tune-file','--idle-secs','0']
 p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
 (out/f'final-{i}.log').write_bytes(p.stdout)
 text=p.stdout.decode('utf8','replace');match=re.search(r'\bhps=([\d.]+)',text)
 if p.returncode or not match:raise RuntimeError(text[-2000:])
 row={'file':name,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'threads':24,'pads':2,'prefetch':1,'seconds':20,'hps':float(match[1])};rows.append(row);print(row,flush=True)
 (out/'final-comparison.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
