"""Further TowerWalk experiments against the immutable round-2 candidate.
No production files are changed. All work and benchmarks run sequentially.
"""
from pathlib import Path
import os, sys, shutil, subprocess, json, re, hashlib

src = Path(__file__).resolve().parent
desktop = src.parents[1]
out = desktop/'artifacts/jtm-round3'
out.mkdir(parents=True, exist_ok=True)
lab = desktop/'experiments/jetsam-lab-round3'
if not lab.exists():
    shutil.copytree(src, lab, ignore=shutil.ignore_patterns('__pycache__', 'target'))
base = (desktop/'artifacts/jtm-round2/recompute.rs').read_text(encoding='utf8')
baseline = desktop/'artifacts/jtm-round2/recompute.exe'
assert hashlib.sha256(baseline.read_bytes()).hexdigest() == 'f16c35b766a45dd596df2ef0b10dfb9ce4b4f3676f5c639c7015f52b24b02907'
build = Path(os.environ['LOCALAPPDATA'])/'GozeroBuild/blocknet-0.1'
env = dict(os.environ)
env.update(PATH=str(build/'rust/bin')+';'+str(build.parent/'xmrig-cpu-6.26.0/toolchain/mingw64/bin')+';'+env['PATH'],
           CARGO_HOME=str(build/'cargo-home'), CARGO_TARGET_DIR=str(build.parent/'jtm-lab/target'), CARGO_BUILD_JOBS='4')

def asm_kernel(interleave=False, bmi2=False, distributive=False):
    """Keep eight accumulators in registers throughout 8192 rounds.
    Only used for exactly two contiguous pads, normal consensus lane order.
    The generic Rust path remains the fallback for every other shape.
    """
    lanes = [(p,l) for p in range(2) for l in range(4)]
    if interleave: lanes = [(p,l) for l in range(4) for p in range(2)]
    variants = []
    for pf in (True, False):
        instructions = ['2:']
        for p,l in lanes:
            a = '{a%d%d}' % (p,l)
            addr = '[{base} + {idx}*8 + %d]' % (p*524288)
            instructions += [f'mov {{idx}}, {a}', 'shr {idx}, 32', f'xor {{idx}}, {a}',
                'and {idx:e}, {mask}', f'mov {{val}}, qword ptr {addr}', f'xor {a}, {{val}}',
                f'add {a}, {{round}}', f'imul {a}, {{mult}}', f'mov {{tmp}}, {a}',
                'shr {tmp}, {shift}', f'xor {a}, {{tmp}}', f'add {{val}}, {a}',
                f'mov qword ptr {addr}, {{val}}']
            if pf:
                instructions += [f'mov {{idx}}, {a}', 'shr {idx}, 32', f'xor {{idx}}, {a}',
                                 'and {idx:e}, {mask}', f'prefetcht0 {addr}']
        instructions += ['add {round}, {mult}' if distributive else 'add {round}, 1', 'test {round}, {period_mask}', 'jnz 2b']
        if distributive:
            for p,l in lanes:
                a = '{a%d%d}' % (p,l)
                i = instructions.index(f'add {a}, {{round}}')
                assert instructions[i+1] == f'imul {a}, {{mult}}'
                instructions[i:i+2] = [f'imul {a}, {{mult}}', f'add {a}, {{round}}']
        if bmi2:
            text = '\n'.join(instructions)
            for p,l in lanes:
                a = '{a%d%d}' % (p,l)
                text = text.replace(f'mov {{idx}}, {a}\nshr {{idx}}, 32', f'rorx {{idx}}, {a}, 32')
            instructions = text.splitlines()
        lines = ['core::arch::asm!('] + [json.dumps(s)+',' for s in instructions]
        lines += [f'a{p}{l}=inout(reg) a[{p}][{l}],' for p,l in [(p,l) for p in range(2) for l in range(4)]]
        lines += ['base=in(reg) pads[0], round=inout(reg) r => _, mult=in(reg) MULT_C,',
                  'idx=out(reg) _, val=out(reg) _, tmp=out(reg) _,',
                  'mask=const INDEX_MASK, shift=const XS, period_mask=const (PERM_PERIOD-1),',
                  'options(nostack),', ');']
        variants.append('\n'.join(lines))
    preamble = 'let r = r.wrapping_mul(MULT_C);' if distributive else ''
    return '''
// Lab: a complete 8192-round chunk. Ordinary memory side effects are declared;
// no nomem/readonly/pure flags, and no modification of consensus work count.
#[inline(always)]
unsafe fn asm_chunk2<const PF:bool>(pads:&[*mut u64], a:&mut [[u64;4]], r:u64) {
    const _: () = assert!(PERM_PERIOD.is_power_of_two() && PAD_BYTES == 524288 && MULT_C & 1 == 1);
    // When distributive: ((a^val)+r)*C == (a^val)*C+r*C (mod 2^64).
    // C is odd, so r*C has the same 8192-round zero-mask boundary as r.
''' + preamble + '\n    if PF {' + variants[0] + '} else {' + variants[1] + '}\n}\n' + '''
#[cfg(test)]
#[test]
fn lab_distributive_and_rotate_identities() {
    let mut x = 0xfedcba9876543210u64;
    for r in 0..ROUNDS as u64 {
        x = x.wrapping_mul(6364136223846793005).wrapping_add(1);
        for a in [0u64, u64::MAX, x] {
            assert_eq!(a.wrapping_add(r).wrapping_mul(MULT_C),
                       a.wrapping_mul(MULT_C).wrapping_add(r.wrapping_mul(MULT_C)));
            assert_eq!((a ^ (a >> 32)) & INDEX_MASK,
                       (a ^ a.rotate_right(32)) & INDEX_MASK);
        }
        assert_eq!(r & (PERM_PERIOD as u64-1) == 0,
                   r.wrapping_mul(MULT_C) & (PERM_PERIOD as u64-1) == 0);
    }
}
'''

name = sys.argv[1]
walk = base
windows = (src/'towerminer/src/sys_windows.rs').read_text(encoding='utf8')
if name in ('asm', 'asm-lane', 'asm-bmi2', 'asm-distributive', 'asm-bmi2-distributive', 'avx2-gather'):
    begin = '        for rr in r..r + PERM_PERIOD {'
    end = '        r += PERM_PERIOD;'
    start = walk.index(begin)
    stop = walk.index(end, start)
    loop = walk[start:stop]
    condition = 'P == 2 && !MUTANT && pads[1] == pads[0].add(CELLS)'
    if 'bmi2' in name: condition += ' && std::is_x86_feature_detected!("bmi2")'
    if name == 'avx2-gather': condition = 'P == 2 && !MUTANT && std::is_x86_feature_detected!("avx2")'
    walk = walk[:start] + '        if ' + condition + ''' {
            asm_chunk2::<PF>(pads, &mut a, r as u64);
        } else {
''' + loop + '        }\n' + walk[stop:]
    if name == 'avx2-gather':
        walk = walk.replace('asm_chunk2::<PF>', 'avx2_chunk2::<PF>')
        walk += (src/'avx2_chunk_lab.rs').read_text(encoding='utf8')
    else:
        walk += asm_kernel(name == 'asm-lane', 'bmi2' in name, 'distributive' in name)
elif name == 'prefetch-l2':
    walk = walk.replace('_MM_HINT_T0', '_MM_HINT_T1')
elif name == 'prefetch-none':
    walk = walk.replace('if PF {', 'if false && PF {')
elif name == 'skew64':
    windows = windows.replace('let need = pads * PAD_BYTES;', 'let need = pads * (PAD_BYTES + 64);')
    windows = windows.replace('base.add(k * PAD_BYTES)', 'base.add(k * (PAD_BYTES + 64))')
elif name == 'byte-address':
    walk = walk.replace('v.add(off_of(*a))', 'v.add(((((*a) << 3) ^ ((*a) >> 29)) & OFF_MASK) as usize)')
else:
    raise ValueError(name)
(lab/'towerminer/src/walk.rs').write_text(walk, encoding='utf8')
(lab/'towerminer/src/sys_windows.rs').write_text(windows, encoding='utf8')
(out/(name+'.rs')).write_text(walk, encoding='utf8')
(out/(name+'-sys_windows.rs')).write_text(windows, encoding='utf8')
with (out/(name+'-build.log')).open('wb') as f:
    result = subprocess.run([str(build/'rust/bin/cargo.exe'), 'build', '--release', '--locked',
        '--manifest-path', str(lab/'Cargo.toml')], env=env, stdout=f, stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW)
if result.returncode:
    print((out/(name+'-build.log')).read_text(encoding='utf8')[-5000:])
    raise SystemExit(result.returncode)
exe = out/(name+'.exe')
shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'release/towerminer.exe', exe)
with (out/(name+'-gate.log')).open('wb') as f:
    result = subprocess.run([str(exe), '--gate'], stdout=f, stderr=subprocess.STDOUT,
                            timeout=180, creationflags=subprocess.CREATE_NO_WINDOW)
if result.returncode:
    print((out/(name+'-gate.log')).read_text(encoding='utf8')[-5000:])
    raise SystemExit(result.returncode)
print(name+' GATE PASS', flush=True)
if '--build-only' not in sys.argv:
    result = subprocess.run([sys.executable, str(src/'compare_round3.py'), name, '15', '4'])
    raise SystemExit(result.returncode)
