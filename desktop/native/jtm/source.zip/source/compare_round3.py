"""Compare directly with last round's best, not a weaker historical baseline."""
from pathlib import Path
import subprocess, re, json, hashlib, sys
desktop = Path(__file__).resolve().parents[2]
out = desktop/'artifacts/jtm-round3'
name = sys.argv[1]
secs = int(sys.argv[2]) if len(sys.argv)>2 else 30
threads = int(sys.argv[3]) if len(sys.argv)>3 else 24
reverse = 'reverse' in sys.argv
triple = 'triple' in sys.argv
tag = f'{name}-t{threads}-s{secs}' + ('-reverse' if reverse else '') + ('-triple' if triple else '')
base = desktop/'artifacts/jtm-round2/recompute.exe'
candidate = out/(name+'.exe')
a, b = (base, 'round2'), (candidate, name)
order = [b,a,a,b] if reverse else [a,b,b,a]
if triple:
    shipped=(desktop/'native/jtm/GozeroJtmCore.exe','shipped')
    order=[shipped,a,b,b,a,shipped]
rows=[]
for i,(exe,label) in enumerate(order):
    args=[str(exe),'--bench-walk',str(secs),'--threads',str(threads),'--pads','2',
          '--prefetch','1','--no-tune-file','--idle-secs','0']
    result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                          timeout=secs+45,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/f'{tag}-{i}.log').write_bytes(result.stdout)
    match=re.search(rb'\bhps=([\d.]+)',result.stdout)
    if result.returncode or not match: raise RuntimeError(result.stdout.decode('utf8','replace')[-2000:])
    row={'label':label,'hps':float(match[1]),'threads':threads,'seconds':secs,
         'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
    rows.append(row);print(row,flush=True)
    (out/(tag+'.json')).write_text(json.dumps(rows,indent=2),encoding='utf8')
means={label:sum(r['hps'] for r in rows if r['label']==label)/2 for label in set(r['label'] for r in rows)}
print({'means':means,'change_percent':100*(means[name]/means['round2']-1)},flush=True)
