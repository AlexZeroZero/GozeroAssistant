"""Stage the verified final JTM core, source, notices and SHA-256 metadata."""
from pathlib import Path
import os, json, shutil, hashlib, zipfile, tomllib
src=Path(__file__).resolve().parent
desktop=src.parents[1]
out=desktop/'native/jtm';out.mkdir(parents=True,exist_ok=True)
art=desktop/'artifacts/jtm'
version=tomllib.loads((src/'towerminer/Cargo.toml').read_text(encoding='utf-8'))['package']['version']
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copy2(art/'GozeroJtmCore.exe',out/'GozeroJtmCore.exe')
shutil.copy2(src/'LICENSE',out/'LICENSE-TowerMiner.txt')
shutil.copy2(src/'GOZERO-NOTES.txt',out/'README.txt')
shutil.copy2(src/'VALIDATION.txt',out/'VALIDATION.txt')
lock=tomllib.loads((src/'Cargo.lock').read_text(encoding='utf-8'))
registry=Path(os.environ['LOCALAPPDATA'])/'GozeroBuild/blocknet-0.1/cargo-home/registry/src'
notices=[]
with zipfile.ZipFile(out/'source.zip','w',zipfile.ZIP_DEFLATED,strict_timestamps=False) as z:
 for p in sorted(src.rglob('*')):
  if p.is_file() and not any(v in ('target','.git','__pycache__') for v in p.relative_to(src).parts):z.write(p,'source/'+p.relative_to(src).as_posix())
 for pkg in lock['package']:
  if not pkg.get('source','').startswith('registry+'):continue
  matches=list(registry.glob('*/'+pkg['name']+'-'+pkg['version']))
  if not matches:continue # Non-Windows dependencies need not be built locally.
  d=matches[0];meta=tomllib.loads((d/'Cargo.toml').read_text(encoding='utf-8'))['package']
  notices.append(pkg['name']+' '+pkg['version']+' — '+meta.get('license','see bundled license'))
  for p in d.rglob('*'):
   if p.is_file() and p.name.lower().startswith(('license','copying','notice')):
    z.write(p,'dependency-licenses/'+d.name+'/'+p.relative_to(d).as_posix())
 for name in ['gate.log','nonces.log','test.log','rpc-test.log','assistant-tests.log','consensus-audit.json','comparison.json','simple-comparison.json','profile-comparison.json','final-comparison.json','native-smoke.json','ui-smoke.json']:
  p=art/name
  if p.exists():z.write(p,'validation/prior-1.0.54/'+name)
 for directory in ['jtm-round3','release-1.0.55','release-1.0.57']:
  evidence=desktop/'artifacts'/directory
  for p in sorted(evidence.glob('*')):
   if p.is_file() and p.suffix in ('.txt','.json','.log','.patch'):
    z.write(p,'validation/'+directory+'/'+p.name)
 z.writestr('dependency-licenses/INDEX.txt','\n'.join(notices)+'\n')
(out/'DEPENDENCIES.txt').write_text('License texts in source.zip/dependency-licenses\n\n'+'\n'.join(notices)+'\n',encoding='utf-8')
meta=json.loads((desktop/'src/jtm-kernel.json').read_text(encoding='utf-8'))
meta.update(id='gozero-jtm-'+version,version=version,exeSha256=digest(out/'GozeroJtmCore.exe'),files={p.name:digest(p) for p in sorted(out.iterdir()) if p.is_file()})
(desktop/'src/jtm-kernel.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
dist=desktop/'dist';dist.mkdir(exist_ok=True)
bundle=dist/('GozeroJtmCore-'+version+'-win-x64.zip')
with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED,strict_timestamps=False) as z:
 for p in sorted(out.iterdir()):
  if p.is_file():z.write(p,'GozeroJtmCore/'+p.name)
bundle.with_suffix('.zip.sha256').write_text(digest(bundle)+'  '+bundle.name+'\n',encoding='ascii')
print(meta['exeSha256']);print(bundle)
