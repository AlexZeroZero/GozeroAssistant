// SPDX-License-Identifier: Apache-2.0
// Experimental vector path: independent lanes only. Collisions retain sequential
// semantics. The public dispatch checks AVX2 before calling this function.
#[target_feature(enable = "avx2")]
unsafe fn avx2_chunk2<const PF: bool>(pads: &[*mut u64], a: &mut [[u64; 4]], r: u64) {
    use core::arch::x86_64::*;
    let mut state = [_mm256_loadu_si256(a[0].as_ptr() as *const __m256i),
                     _mm256_loadu_si256(a[1].as_ptr() as *const __m256i)];
    let mask = _mm256_set1_epi64x(INDEX_MASK as i64);
    let clo = _mm256_set1_epi64x(MULT_C as i64);
    let chi = _mm256_set1_epi64x((MULT_C >> 32) as i64);
    for rr in r..r + PERM_PERIOD as u64 {
        let round = _mm256_set1_epi64x(rr as i64);
        for p in 0..2 {
            let old = state[p];
            let idx = _mm256_and_si256(_mm256_xor_si256(old, _mm256_srli_epi64::<32>(old)), mask);
            // Rotations by one and two cover all six unordered pairs.
            let alias = _mm256_or_si256(
                _mm256_cmpeq_epi64(idx, _mm256_permute4x64_epi64::<0x39>(idx)),
                _mm256_cmpeq_epi64(idx, _mm256_permute4x64_epi64::<0x4e>(idx)));
            if _mm256_testz_si256(alias, alias) == 0 {
                _mm256_storeu_si256(a[p].as_mut_ptr() as *mut __m256i, old);
                let mut unused_offset = 0;
                for li in 0..4 {
                    let l = LANES[li];
                    step::<false, PF>(pads[p] as *mut u8, &mut unused_offset, &mut a[p][l], rr);
                }
                state[p] = _mm256_loadu_si256(a[p].as_ptr() as *const __m256i);
                continue;
            }
            let val = _mm256_i64gather_epi64::<8>(pads[p] as *const i64, idx);
            let x = _mm256_add_epi64(_mm256_xor_si256(old, val), round);
            // Low 64 bits of a 64x64 product, using three unsigned 32x32 products.
            let low = _mm256_mul_epu32(x, clo);
            let high = _mm256_add_epi64(_mm256_mul_epu32(_mm256_srli_epi64::<32>(x), clo),
                                        _mm256_mul_epu32(x, chi));
            let y = _mm256_add_epi64(low, _mm256_slli_epi64::<32>(high));
            let next = _mm256_xor_si256(y, _mm256_srli_epi64::<{XS as i32}>(y));
            state[p] = next;
            let written = _mm256_add_epi64(next, val);
            let mut indices = [0u64; 4];
            let mut values = [0u64; 4];
            _mm256_storeu_si256(indices.as_mut_ptr() as *mut __m256i, idx);
            _mm256_storeu_si256(values.as_mut_ptr() as *mut __m256i, written);
            for l in 0..4 { *pads[p].add(indices[l] as usize) = values[l]; }
            if PF {
                let next_idx = _mm256_and_si256(_mm256_xor_si256(next, _mm256_srli_epi64::<32>(next)), mask);
                _mm256_storeu_si256(indices.as_mut_ptr() as *mut __m256i, next_idx);
                for l in 0..4 { _mm_prefetch::<_MM_HINT_T0>(pads[p].add(indices[l] as usize) as *const i8); }
            }
        }
    }
    _mm256_storeu_si256(a[0].as_mut_ptr() as *mut __m256i, state[0]);
    _mm256_storeu_si256(a[1].as_mut_ptr() as *mut __m256i, state[1]);
}

#[cfg(test)]
#[test]
fn lab_avx2_collision_patterns() {
    assert!(std::is_x86_feature_detected!("avx2"), "This experiment requires an AVX2 test host");
    for pattern in 0..256usize {
        let offsets = [(pattern&3) as u64, ((pattern>>2)&3) as u64,
                       ((pattern>>4)&3) as u64, ((pattern>>6)&3) as u64];
        let mut expected = [vec![0u64; CELLS], vec![0u64; CELLS]];
        for p in 0..2 { for i in 0..CELLS { expected[p][i] = (i as u64).wrapping_mul(MULT_C) ^ p as u64; } }
        let mut actual = expected.clone();
        let mut reference_state = [offsets, offsets];
        let mut actual_state = reference_state;
        unsafe {
            for rr in 0..PERM_PERIOD as u64 {
                for p in 0..2 { for l in 0..4 {
                    let mut off = 0;
                    step::<false,true>(expected[p].as_mut_ptr() as *mut u8, &mut off, &mut reference_state[p][l], rr);
                } }
            }
            let ptrs = [actual[0].as_mut_ptr(), actual[1].as_mut_ptr()];
            avx2_chunk2::<true>(&ptrs, &mut actual_state, 0);
        }
        assert_eq!(actual_state, reference_state, "state pattern={pattern}");
        assert_eq!(actual, expected, "memory pattern={pattern}");
    }
}
