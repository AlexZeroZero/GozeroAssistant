"""Validate the retained experimental binary and arithmetic identities."""
from pathlib import Path
import os, subprocess, sys, ast

src=Path(__file__).resolve().parent
desktop=src.parents[1]
out=desktop/'artifacts/jtm-round3'
lab=desktop/'experiments/jetsam-lab-round3'
name=sys.argv[1]
if len(sys.argv)>2 and sys.argv[2] in ('identities','collisions'):
    # Load only the generator function, not the runner's top-level build/bench code.
    tree=ast.parse((src/'lab_round3.py').read_text(encoding='utf8'))
    function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='asm_kernel')
    import json
    namespace={'json':json}
    exec(compile(ast.Module(body=[function],type_ignores=[]),'<asm-generator>','exec'),namespace)
    generated=namespace['asm_kernel'](False,True,True)
    identity=generated[generated.index('#[cfg(test)]'):]
    (out/'identity-tests.rs').write_text(identity,encoding='utf8')
    candidate_source=(out/(name+'.rs')).read_text(encoding='utf8')
    if sys.argv[2]=='identities' and 'fn lab_distributive_and_rotate_identities' not in candidate_source:
        candidate_source+='\n'+identity
    (lab/'towerminer/src/walk.rs').write_text(candidate_source,encoding='utf8')
    (lab/'towerminer/src/sys_windows.rs').write_text((out/(name+'-sys_windows.rs')).read_text(encoding='utf8'),encoding='utf8')
    root=Path(os.environ['LOCALAPPDATA'])/'GozeroBuild/blocknet-0.1'
    env=dict(os.environ)
    env.update(PATH=str(root/'rust/bin')+';'+str(root.parent/'xmrig-cpu-6.26.0/toolchain/mingw64/bin')+';'+env['PATH'],
               CARGO_HOME=str(root/'cargo-home'),CARGO_TARGET_DIR=str(root.parent/'jtm-lab/target'),CARGO_BUILD_JOBS='4')
    filter_name='lab_distributive_and_rotate_identities' if sys.argv[2]=='identities' else 'lab_avx2_collision_patterns'
    args=[str(root/'rust/bin/cargo.exe'),'test','--release','--locked','--manifest-path',str(lab/'Cargo.toml'),
          filter_name,'--','--nocapture']
    log=out/('identity-test.log' if sys.argv[2]=='identities' else 'collision-test.log')
else:
    env=dict(os.environ)
    args=[str(out/(name+'.exe')),'--check-nonces','25','--threads','4','--pads','2','--prefetch','1','--no-tune-file','--idle-secs','0']
    log=out/(name+'-nonces.log')
with log.open('wb') as f:
    r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240,creationflags=subprocess.CREATE_NO_WINDOW)
text=log.read_text(encoding='utf8',errors='replace')
print(text[-2400:])
if len(sys.argv)>2 and sys.argv[2] in ('identities','collisions') and '1 passed' not in text:
    raise RuntimeError('Expected identity test did not pass')
raise SystemExit(r.returncode)
