"""Sequential ABBA of immutable binaries; writes every raw benchmark log."""
from pathlib import Path
import subprocess, re, json, hashlib, sys

desktop = Path(__file__).resolve().parents[2]
out = desktop / 'artifacts/jtm-round2'
name = sys.argv[1]
seconds = int(sys.argv[2]) if len(sys.argv) > 2 else 25
threads = int(sys.argv[3]) if len(sys.argv) > 3 else 24
pads = int(sys.argv[4]) if len(sys.argv) > 4 else 2
tag = f'{name}-t{threads}-p{pads}-s{seconds}'
reverse = len(sys.argv) > 5 and sys.argv[5] == 'reverse'
if reverse:
    tag += '-reverse'
baseline = desktop / 'native/jtm/GozeroJtmCore.exe'
candidate = out / (name + '.exe')
rows = []
order = [(baseline, 'shipped'), (candidate, name), (candidate, name), (baseline, 'shipped')]
if reverse:
    order = [(candidate, name), (baseline, 'shipped'), (baseline, 'shipped'), (candidate, name)]
for i, (exe, label) in enumerate(order):
    args = [str(exe), '--bench-walk', str(seconds), '--threads', str(threads),
            '--pads', str(pads), '--prefetch', '1', '--no-tune-file', '--idle-secs', '0']
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            timeout=seconds + 45, creationflags=subprocess.CREATE_NO_WINDOW)
    (out / f'{tag}-{i}.log').write_bytes(result.stdout)
    rate = re.search(rb'\bhps=([\d.]+)', result.stdout)
    if result.returncode or not rate:
        raise RuntimeError(result.stdout.decode('utf8', 'replace')[-2000:])
    row = {'label': label, 'hps': float(rate[1]), 'seconds': seconds, 'threads': threads,
           'pads': pads, 'sha256': hashlib.sha256(exe.read_bytes()).hexdigest()}
    rows.append(row)
    (out / f'{tag}.json').write_text(json.dumps(rows, indent=2), encoding='utf8')
    print(row, flush=True)
means = {label: sum(r['hps'] for r in rows if r['label'] == label) / 2
         for label in ('shipped', name)}
print({'means': means, 'change_percent': 100 * (means[name] / means['shipped'] - 1)}, flush=True)
