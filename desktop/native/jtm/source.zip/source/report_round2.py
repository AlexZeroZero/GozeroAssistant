"""Summarize saved measurements; do not infer live-pool performance."""
from pathlib import Path
import json, hashlib, difflib, re

desktop = Path(__file__).resolve().parents[2]
out = desktop / 'artifacts/jtm-round2'
records = []
for path in sorted(out.glob('*.json')):
    data = json.loads(path.read_text(encoding='utf8'))
    if not isinstance(data, list) or len(data) != 4 or not all('label' in r for r in data):
        continue
    labels = sorted(set(r['label'] for r in data))
    if 'shipped' not in labels or len(labels) != 2:
        continue
    name = next(n for n in labels if n != 'shipped')
    means = {n: sum(r['hps'] for r in data if r['label'] == n)/2 for n in labels}
    records.append({'file': path.name, 'candidate': name, 'threads': data[0]['threads'],
                    'baseline_hps': means['shipped'], 'candidate_hps': means[name],
                    'change_percent': (means[name]/means['shipped']-1)*100,
                    'samples': data})
(out/'summary.json').write_text(json.dumps(records, indent=2), encoding='utf8')
base = (desktop/'experiments/jetsam/towerminer/src/walk.rs').read_text(encoding='utf8')
candidate = (out/'recompute.rs').read_text(encoding='utf8')
(out/'recompute.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True), candidate.splitlines(True),
      fromfile='a/towerminer/src/walk.rs', tofile='b/towerminer/src/walk.rs')), encoding='utf8')
report = ['JTM TowerWalk 优化研究 / 第二轮 / 2026-10-18', '',
    '结论：保留 recompute 为优化候选。24 线程两组交叉对照分别 +3.89% 和 +8.02%；',
    '这是本机离线结果，尚不足以承诺所有 CPU 固定提升，更没有证明数倍提速。',
    '候选通过完整算法门禁和 nonce 校验；正式助手暂保留 1.0.54。',
    '候选 EXE：recompute.exe；对应源码：recompute.rs；补丁：recompute.patch。',
    '候选 SHA256：'+hashlib.sha256((out/'recompute.exe').read_bytes()).hexdigest(), '',
    '范围：本机 Intel Core Ultra 9 275HX，24 核 / 24 线程；普通 4 KiB 页。',
    '基线：助手 1.0.54 中的 GozeroJtmCore 0.3.1-gozero.1；热循环与所审查 TowerMiner 官方源码一致。',
    '官方源码基点：81d16ca17a8c349737dee682031523fc14fbf340。',
    '发布内核 SHA256：'+hashlib.sha256((desktop/'native/jtm/GozeroJtmCore.exe').read_bytes()).hexdigest(),
    '', '方法：每组串行运行 A/B/B/A，或标注 reverse 的 B/A/A/B；每个进程预热 2 秒。',
    '不同组的绝对速率不能直接比较。没有锁定频率/温度/功率，也没有读取到这些传感数据。',
    '同组参数：pads=2、prefetch=1、idle=0、相同线程数和优先级。hetero 例外：P 核 3 链、E 核 2 链。',
    'hetero 使用本机已测 CPU 编号，仅为实验，不能部署到其他机器。native 也仅为本机实验。',
    '编译、校验、测速均串行；没有后台并行编译干扰测速。', '', '对照结果（H/s；算术均值）：']
for row in records:
    report.append(f"{row['file']}: 基线 {row['baseline_hps']:.2f}，实验 {row['candidate_hps']:.2f}，变化 {row['change_percent']:+.2f}%")
probe = (out/'phase-profile.log').read_text(encoding='utf8')
phases = re.findall(r'PHASE calls=(\d+) fill_ns=(\d+) fold_ns=(\d+) walk_ns=(\d+)', probe)
if phases:
    calls, fill, fold, walk = map(int, phases[-1])
    total = fill + fold + walk
    report += ['', f'阶段采样：填充 {100*fill/total:.2f}%，折叠 {100*fold/total:.2f}%，随机读写循环 {100*walk/total:.2f}%。',
               '这是带计时插桩的 4 线程/2 链采样；不包含所有助手/网络开销，不是硬件性能计数器。']
report += ['', '算法检查：',
    '- 每个候选均独立通过 --gate；覆盖 256 个 golden vectors、1000 个随机种子，1–4 链，预取开关和不同槽位。',
    '- 地址碰撞专项覆盖 256 种地址排列 × 3 种轮次 × 3 种实现，内存内容、状态和下一地址均与顺序步骤一致。',
    '- TowerWalk 每 nonce 填满 512 KiB，再执行 131072 轮 × 4 通道随机读写；保留所有周期折叠和最终折叠。',
    '- 访存地址从状态推导，可实验性减少长期存活地址变量；不能改变读写顺序、轮数或乘法/xorshift 常量。',
    '', '提交路径验证：']
for name in ('recompute', 'hetero'):
    path = out/(name+'-nonces.log')
    if path.exists():
        report.extend(line for line in path.read_text(encoding='utf8', errors='replace').splitlines() if line.startswith('CHECK-NONCES'))
report += ['', '边界：',
    '- 目前没有可用 JTM 矿池，因此没有实池接受率、结算收益或服务费结算验证。',
    '- 本机成绩不能外推至 AMD、其它 Intel 或 GPU，也不能把分组测试相加当作整机成绩。',
    '- 未改变安全软件、管理员权限、系统电源配置或大页权限。',
    '- 实验结果未替换助手正式内核，未修改 MDS，未发布 GitHub。',
    '- 上轮记录的原生 RPC 单元测试超时问题仍保留；本轮专项校验不代表该问题已修复。',
    '', '全部原始日志、源码快照、SHA256、对照 JSON 及复现实验脚本均已保留。']
(out/'ROUND2-VALIDATION.txt').write_text('\n'.join(report)+'\n', encoding='utf8')
print('\n'.join(report))
