"""Record actual Windows cache/core topology for the local experiment."""
import ctypes, struct, json
from pathlib import Path

api = ctypes.WinDLL('kernel32', use_last_error=True).GetLogicalProcessorInformationEx
api.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
api.restype = ctypes.c_int
size = ctypes.c_ulong()
api(0xffff, None, ctypes.byref(size))
buf = ctypes.create_string_buffer(size.value)
if not api(0xffff, buf, ctypes.byref(size)):
    raise ctypes.WinError(ctypes.get_last_error())
raw = buf.raw
records = []
pos = 0
while pos < size.value:
    kind, length = struct.unpack_from('<II', raw, pos)
    if length < 8 or pos + length > size.value:
        raise RuntimeError('Invalid topology record')
    data = raw[pos+8:pos+length]
    if kind == 0:
        count = struct.unpack_from('<H', data, 22)[0]
        groups = []
        for n in range(count):
            mask, group = struct.unpack_from('<QH', data, 24+16*n)
            groups.append({'group': group, 'cpus': [b for b in range(64) if mask >> b & 1]})
        records.append({'kind': 'core', 'efficiencyClass': data[1], 'groups': groups})
    elif kind == 2:
        mask, group = struct.unpack_from('<QH', data, 32)
        records.append({'kind': 'cache', 'level': data[0],
                        'bytes': struct.unpack_from('<I', data, 4)[0], 'group': group,
                        'cpus': [b for b in range(64) if mask >> b & 1]})
    pos += length
dest = Path(__file__).resolve().parents[2] / 'artifacts/jtm-round2/topology.json'
dest.write_text(json.dumps(records, indent=2), encoding='utf8')
print(dest)
